var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var otpSchema = new Schema({
    weShareId:{
       type: Number
    },  
    otp:{
        type: Number
    },
    contact:{
        type: Number
    }
}, { timestamps: { createdAt: 'created_at' } });
var User = mongoose.model('Otp', otpSchema);

module.exports  = User;